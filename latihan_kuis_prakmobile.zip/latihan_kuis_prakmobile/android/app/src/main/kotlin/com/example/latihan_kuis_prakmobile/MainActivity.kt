package com.example.latihan_kuis_prakmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
